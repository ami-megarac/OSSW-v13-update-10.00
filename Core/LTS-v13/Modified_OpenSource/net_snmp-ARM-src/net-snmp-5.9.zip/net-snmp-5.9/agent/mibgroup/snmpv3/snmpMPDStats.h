#ifndef _MIBGROUP_SNMPMPDSTATS_H
#define _MIBGROUP_SNMPMPDSTATS_H

config_add_mib(SNMP-MPD-MIB)

void init_snmpMPDStats(void);
void shutdown_snmpMPDStats(void);

#endif /* _MIBGROUP_SNMPMPDSTATS_H */
