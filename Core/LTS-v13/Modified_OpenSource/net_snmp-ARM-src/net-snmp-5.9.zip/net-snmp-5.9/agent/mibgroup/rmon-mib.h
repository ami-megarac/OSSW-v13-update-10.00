/*
 * module to include the modules
 */

config_require(rmon-mib/etherStatsTable)
config_add_mib(RMON-MIB)


