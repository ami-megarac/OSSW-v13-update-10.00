/*
 * module to include the modules
 */

config_require(udp-mib/udpEndpointTable/udpEndpointTable)
