void netsnmp_fsys_arch_init(void);
void netsnmp_fsys_arch_load(void);
