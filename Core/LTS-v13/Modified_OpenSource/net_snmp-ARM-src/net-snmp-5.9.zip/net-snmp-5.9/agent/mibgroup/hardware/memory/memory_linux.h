config_require(hardware/memory/hw_mem)
