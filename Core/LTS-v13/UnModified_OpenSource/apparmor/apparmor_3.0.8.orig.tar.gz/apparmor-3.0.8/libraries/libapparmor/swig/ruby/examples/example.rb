require 'AppArmorLogRecordParser'

