create signal (kill) tests
