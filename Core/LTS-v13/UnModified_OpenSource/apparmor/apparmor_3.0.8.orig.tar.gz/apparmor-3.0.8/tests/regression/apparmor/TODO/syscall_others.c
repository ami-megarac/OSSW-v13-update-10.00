/* tests need to be added for the following syscalls (one per C file)
 * and linked into the syscall.sh driver
 *
 * create_module
 * init_module
 * delete_module
 * vm86, vm86old (unsure if these are possible)
 */
