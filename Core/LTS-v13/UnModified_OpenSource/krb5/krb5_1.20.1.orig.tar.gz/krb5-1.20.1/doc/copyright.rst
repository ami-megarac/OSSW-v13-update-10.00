Copyright
=========

Copyright |copy| 1985-2022 by the Massachusetts Institute of
Technology and its contributors.  All rights reserved.

See :ref:`mitK5license` for additional copyright and license
information.
