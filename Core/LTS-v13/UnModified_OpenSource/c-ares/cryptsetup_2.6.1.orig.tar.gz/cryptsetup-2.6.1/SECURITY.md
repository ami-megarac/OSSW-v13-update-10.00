# Reporting a Security Bug in cryptsetup project

If you think you have discovered a security issue, please report it through
the project issue tracker [New issue](https://gitlab.com/cryptsetup/cryptsetup/issues)
as a confidential issue (select confidential checkbox).

An alternative is to send PGP encrypted mail to the cryptsetup maintainer.
Current maintainer is [Milan Broz](mailto:gmazyland@gmail.com), use PGP key
with fingerprint 2A29 1824 3FDE 4664 8D06 86F9 D9B0 577B D93E 98FC.

