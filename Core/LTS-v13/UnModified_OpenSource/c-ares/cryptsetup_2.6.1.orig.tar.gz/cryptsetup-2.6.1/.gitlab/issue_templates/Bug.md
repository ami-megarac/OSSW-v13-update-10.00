### Issue description
<!-- Please, shortly describe the issue here. -->

### Steps for reproducing the issue
<!-- How it can be reproduced? Include all important steps. -->

### Additional info
<!-- Please mention what distribution you are using. -->

### Debug log
<!-- Paste a debug log of the failing command (add --debug option) between the markers below (to keep raw debug format).-->
```
Output with --debug option:

```
