### New feature description
<!-- Please, shortly describe the requested feature here. -->

### Additional info
<!-- Please mention what distribution and cryptsetup version you are using. -->
