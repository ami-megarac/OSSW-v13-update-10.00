Preface   {#mainpage}
=======

\section Scope Scope of the Document
This document describes the UCX programming
interface.  The programming interface exposes a high performance
communication API, which provides basic building blocks for PGAS, Message
Passing Interface (MPI), Big-Data, Analytics, File I/O, and storage library developers.

\section Audience Audience
This manual is intended for programmers who want to
develop parallel programming models like OpenSHMEM, MPI, UPC, Chapel, etc.
The manual assumes that the reader is familiar with the following:
+ Basic concepts of two-sided, one-sided, atomic, and collective operations
+ C programming language

\section Status Document Status
This section briefly describes a list of open
issues in the UCX specification.
+ UCP API - work in progress
+ UCT API - work in progress

\section License
UCX project follows open source development model and the software is
licensed under BSD-3 license.
